import CustomPaletteProvider from "./CustomPaletteProvider";

export default {
  __init__: ["customPaletteProvider"],
  customPaletteProvider: ["type", CustomPaletteProvider]
};
