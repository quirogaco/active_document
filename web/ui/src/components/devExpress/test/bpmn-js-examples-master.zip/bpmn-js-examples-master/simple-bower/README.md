> Removed as of `bpmn-js@0.27.0`.

We've discontinued bower bundles with our `0.27.0` release of bpmn-js.

Checkout our [pre-packaged example](../pre-packaged) for alternative.