GridCell representation
=======================

.. automodule:: bpmn_python.grid_cell_class
.. autoclass:: GridCell
    :members:
